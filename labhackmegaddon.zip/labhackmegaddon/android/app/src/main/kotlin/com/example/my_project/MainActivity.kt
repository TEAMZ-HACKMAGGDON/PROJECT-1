package com.mycompany.labhackmegaddon

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
