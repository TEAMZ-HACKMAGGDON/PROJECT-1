import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'changepassword_widget.dart' show ChangepasswordWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ChangepasswordModel extends FlutterFlowModel<ChangepasswordWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for Oldpassword widget.
  FocusNode? oldpasswordFocusNode;
  TextEditingController? oldpasswordTextController;
  late bool oldpasswordVisibility;
  String? Function(BuildContext, String?)? oldpasswordTextControllerValidator;
  // State field(s) for newpassword widget.
  FocusNode? newpasswordFocusNode;
  TextEditingController? newpasswordTextController;
  String? Function(BuildContext, String?)? newpasswordTextControllerValidator;
  // State field(s) for confirmpassword widget.
  FocusNode? confirmpasswordFocusNode;
  TextEditingController? confirmpasswordTextController;
  String? Function(BuildContext, String?)?
      confirmpasswordTextControllerValidator;

  @override
  void initState(BuildContext context) {
    oldpasswordVisibility = false;
  }

  @override
  void dispose() {
    oldpasswordFocusNode?.dispose();
    oldpasswordTextController?.dispose();

    newpasswordFocusNode?.dispose();
    newpasswordTextController?.dispose();

    confirmpasswordFocusNode?.dispose();
    confirmpasswordTextController?.dispose();
  }
}
