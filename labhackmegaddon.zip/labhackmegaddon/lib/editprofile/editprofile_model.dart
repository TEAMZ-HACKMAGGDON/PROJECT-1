import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'editprofile_widget.dart' show EditprofileWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class EditprofileModel extends FlutterFlowModel<EditprofileWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for emailId widget.
  FocusNode? emailIdFocusNode;
  TextEditingController? emailIdTextController;
  String? Function(BuildContext, String?)? emailIdTextControllerValidator;
  // State field(s) for pharmacyname widget.
  FocusNode? pharmacynameFocusNode;
  TextEditingController? pharmacynameTextController;
  String? Function(BuildContext, String?)? pharmacynameTextControllerValidator;
  // State field(s) for Pharmacyowner widget.
  FocusNode? pharmacyownerFocusNode;
  TextEditingController? pharmacyownerTextController;
  String? Function(BuildContext, String?)? pharmacyownerTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    emailIdFocusNode?.dispose();
    emailIdTextController?.dispose();

    pharmacynameFocusNode?.dispose();
    pharmacynameTextController?.dispose();

    pharmacyownerFocusNode?.dispose();
    pharmacyownerTextController?.dispose();
  }
}
