import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'addstocks_widget.dart' show AddstocksWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AddstocksModel extends FlutterFlowModel<AddstocksWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for addstock widget.
  FocusNode? addstockFocusNode;
  TextEditingController? addstockTextController;
  String? Function(BuildContext, String?)? addstockTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    addstockFocusNode?.dispose();
    addstockTextController?.dispose();
  }
}
