// Export pages
export '/pages/home_page/home_page_widget.dart' show HomePageWidget;
export '/forgotpassword/forgotpassword_widget.dart' show ForgotpasswordWidget;
export '/editprofile/editprofile_widget.dart' show EditprofileWidget;
export '/pharmacypage/pharmacypage_widget.dart' show PharmacypageWidget;
export '/pharmacyprofileview/pharmacyprofileview_widget.dart'
    show PharmacyprofileviewWidget;
export '/changepassword/changepassword_widget.dart' show ChangepasswordWidget;
export '/stocksavialble/stocksavialble_widget.dart' show StocksavialbleWidget;
