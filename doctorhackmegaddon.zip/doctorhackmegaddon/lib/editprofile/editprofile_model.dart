import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'editprofile_widget.dart' show EditprofileWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class EditprofileModel extends FlutterFlowModel<EditprofileWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for firstname widget.
  FocusNode? firstnameFocusNode;
  TextEditingController? firstnameTextController;
  String? Function(BuildContext, String?)? firstnameTextControllerValidator;
  // State field(s) for lastname widget.
  FocusNode? lastnameFocusNode;
  TextEditingController? lastnameTextController;
  String? Function(BuildContext, String?)? lastnameTextControllerValidator;
  // State field(s) for age widget.
  FocusNode? ageFocusNode;
  TextEditingController? ageTextController;
  String? Function(BuildContext, String?)? ageTextControllerValidator;
  // State field(s) for gender widget.
  FocusNode? genderFocusNode;
  TextEditingController? genderTextController;
  String? Function(BuildContext, String?)? genderTextControllerValidator;
  // State field(s) for email widget.
  FocusNode? emailFocusNode;
  TextEditingController? emailTextController;
  String? Function(BuildContext, String?)? emailTextControllerValidator;
  // State field(s) for qualification widget.
  FocusNode? qualificationFocusNode;
  TextEditingController? qualificationTextController;
  String? Function(BuildContext, String?)? qualificationTextControllerValidator;
  // State field(s) for doctorid widget.
  FocusNode? doctoridFocusNode;
  TextEditingController? doctoridTextController;
  String? Function(BuildContext, String?)? doctoridTextControllerValidator;
  // State field(s) for Specialization widget.
  FocusNode? specializationFocusNode;
  TextEditingController? specializationTextController;
  String? Function(BuildContext, String?)?
      specializationTextControllerValidator;
  // State field(s) for yearsofexperience widget.
  FocusNode? yearsofexperienceFocusNode;
  TextEditingController? yearsofexperienceTextController;
  String? Function(BuildContext, String?)?
      yearsofexperienceTextControllerValidator;
  // State field(s) for contact widget.
  FocusNode? contactFocusNode;
  TextEditingController? contactTextController;
  String? Function(BuildContext, String?)? contactTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    firstnameFocusNode?.dispose();
    firstnameTextController?.dispose();

    lastnameFocusNode?.dispose();
    lastnameTextController?.dispose();

    ageFocusNode?.dispose();
    ageTextController?.dispose();

    genderFocusNode?.dispose();
    genderTextController?.dispose();

    emailFocusNode?.dispose();
    emailTextController?.dispose();

    qualificationFocusNode?.dispose();
    qualificationTextController?.dispose();

    doctoridFocusNode?.dispose();
    doctoridTextController?.dispose();

    specializationFocusNode?.dispose();
    specializationTextController?.dispose();

    yearsofexperienceFocusNode?.dispose();
    yearsofexperienceTextController?.dispose();

    contactFocusNode?.dispose();
    contactTextController?.dispose();
  }
}
