// Export pages
export '/home_page/home_page_widget.dart' show HomePageWidget;
export '/profile/profile_widget.dart' show ProfileWidget;
export '/editprofile1/editprofile1_widget.dart' show Editprofile1Widget;
export '/chnagepassword/chnagepassword_widget.dart' show ChnagepasswordWidget;
export '/patientlist/patientlist_widget.dart' show PatientlistWidget;
export '/patientprofiledoctor/patientprofiledoctor_widget.dart'
    show PatientprofiledoctorWidget;
export '/home_page_copy/home_page_copy_widget.dart' show HomePageCopyWidget;
export '/forgotpassword/forgotpassword_widget.dart' show ForgotpasswordWidget;
export '/profileviewdoctor/profileviewdoctor_widget.dart'
    show ProfileviewdoctorWidget;
export '/editprofile/editprofile_widget.dart' show EditprofileWidget;
export '/doctorpage/doctorpage_widget.dart' show DoctorpageWidget;
export '/request/request_widget.dart' show RequestWidget;
