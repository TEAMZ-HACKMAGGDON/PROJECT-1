import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'editprofile1_widget.dart' show Editprofile1Widget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Editprofile1Model extends FlutterFlowModel<Editprofile1Widget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for Firstname widget.
  FocusNode? firstnameFocusNode;
  TextEditingController? firstnameTextController;
  String? Function(BuildContext, String?)? firstnameTextControllerValidator;
  // State field(s) for lastname widget.
  FocusNode? lastnameFocusNode;
  TextEditingController? lastnameTextController;
  String? Function(BuildContext, String?)? lastnameTextControllerValidator;
  // State field(s) for age widget.
  FocusNode? ageFocusNode;
  TextEditingController? ageTextController;
  String? Function(BuildContext, String?)? ageTextControllerValidator;
  // State field(s) for Gender widget.
  FocusNode? genderFocusNode;
  TextEditingController? genderTextController;
  String? Function(BuildContext, String?)? genderTextControllerValidator;
  // State field(s) for qualifiactions widget.
  FocusNode? qualifiactionsFocusNode;
  TextEditingController? qualifiactionsTextController;
  String? Function(BuildContext, String?)?
      qualifiactionsTextControllerValidator;
  // State field(s) for email widget.
  FocusNode? emailFocusNode;
  TextEditingController? emailTextController;
  String? Function(BuildContext, String?)? emailTextControllerValidator;
  // State field(s) for DoctorID widget.
  FocusNode? doctorIDFocusNode;
  TextEditingController? doctorIDTextController;
  String? Function(BuildContext, String?)? doctorIDTextControllerValidator;
  // State field(s) for specialization widget.
  FocusNode? specializationFocusNode;
  TextEditingController? specializationTextController;
  String? Function(BuildContext, String?)?
      specializationTextControllerValidator;
  // State field(s) for yearsofexperience widget.
  FocusNode? yearsofexperienceFocusNode;
  TextEditingController? yearsofexperienceTextController;
  String? Function(BuildContext, String?)?
      yearsofexperienceTextControllerValidator;
  // State field(s) for contact widget.
  FocusNode? contactFocusNode;
  TextEditingController? contactTextController;
  String? Function(BuildContext, String?)? contactTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    firstnameFocusNode?.dispose();
    firstnameTextController?.dispose();

    lastnameFocusNode?.dispose();
    lastnameTextController?.dispose();

    ageFocusNode?.dispose();
    ageTextController?.dispose();

    genderFocusNode?.dispose();
    genderTextController?.dispose();

    qualifiactionsFocusNode?.dispose();
    qualifiactionsTextController?.dispose();

    emailFocusNode?.dispose();
    emailTextController?.dispose();

    doctorIDFocusNode?.dispose();
    doctorIDTextController?.dispose();

    specializationFocusNode?.dispose();
    specializationTextController?.dispose();

    yearsofexperienceFocusNode?.dispose();
    yearsofexperienceTextController?.dispose();

    contactFocusNode?.dispose();
    contactTextController?.dispose();
  }
}
