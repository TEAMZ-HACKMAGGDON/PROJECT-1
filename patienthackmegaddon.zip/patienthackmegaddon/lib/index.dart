// Export pages
export '/pages/home_page/home_page_widget.dart' show HomePageWidget;
export '/womanorchild/womanorchild_widget.dart' show WomanorchildWidget;
export '/editprofilechild/editprofilechild_widget.dart'
    show EditprofilechildWidget;
export '/vaccinationstatus/vaccinationstatus_widget.dart'
    show VaccinationstatusWidget;
export '/editprofilewoman/editprofilewoman_widget.dart'
    show EditprofilewomanWidget;
export '/patientpage/patientpage_widget.dart' show PatientpageWidget;
export '/childprofile/childprofile_widget.dart' show ChildprofileWidget;
export '/profilewoman/profilewoman_widget.dart' show ProfilewomanWidget;
export '/chronicconditions/chronicconditions_widget.dart'
    show ChronicconditionsWidget;
export '/prescriptions/prescriptions_widget.dart' show PrescriptionsWidget;
export '/precriptionviewer/precriptionviewer_widget.dart'
    show PrecriptionviewerWidget;
export '/reports/reports_widget.dart' show ReportsWidget;
export '/reportviwer/reportviwer_widget.dart' show ReportviwerWidget;
export '/videoconferencing/videoconferencing_widget.dart'
    show VideoconferencingWidget;
export '/vclink/vclink_widget.dart' show VclinkWidget;
export '/notfound/notfound_widget.dart' show NotfoundWidget;
export '/reminders/reminders_widget.dart' show RemindersWidget;
export '/ordermedicine/ordermedicine_widget.dart' show OrdermedicineWidget;
export '/orderplaced/orderplaced_widget.dart' show OrderplacedWidget;
export '/changepassword/changepassword_widget.dart' show ChangepasswordWidget;
export '/forgotpassword/forgotpassword_widget.dart' show ForgotpasswordWidget;
export '/pharmacieslist/pharmacieslist_widget.dart' show PharmacieslistWidget;
