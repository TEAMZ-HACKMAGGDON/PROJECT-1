import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'editprofilechild_widget.dart' show EditprofilechildWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class EditprofilechildModel extends FlutterFlowModel<EditprofilechildWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for firstname widget.
  FocusNode? firstnameFocusNode;
  TextEditingController? firstnameTextController;
  String? Function(BuildContext, String?)? firstnameTextControllerValidator;
  // State field(s) for lastname widget.
  FocusNode? lastnameFocusNode;
  TextEditingController? lastnameTextController;
  String? Function(BuildContext, String?)? lastnameTextControllerValidator;
  // State field(s) for firstnamem widget.
  FocusNode? firstnamemFocusNode;
  TextEditingController? firstnamemTextController;
  String? Function(BuildContext, String?)? firstnamemTextControllerValidator;
  // State field(s) for lastnamem widget.
  FocusNode? lastnamemFocusNode;
  TextEditingController? lastnamemTextController;
  String? Function(BuildContext, String?)? lastnamemTextControllerValidator;
  // State field(s) for dob widget.
  FocusNode? dobFocusNode;
  TextEditingController? dobTextController;
  String? Function(BuildContext, String?)? dobTextControllerValidator;
  // State field(s) for gender widget.
  FocusNode? genderFocusNode;
  TextEditingController? genderTextController;
  String? Function(BuildContext, String?)? genderTextControllerValidator;
  // State field(s) for birthweight widget.
  FocusNode? birthweightFocusNode;
  TextEditingController? birthweightTextController;
  String? Function(BuildContext, String?)? birthweightTextControllerValidator;
  // State field(s) for Currentweight widget.
  FocusNode? currentweightFocusNode;
  TextEditingController? currentweightTextController;
  String? Function(BuildContext, String?)? currentweightTextControllerValidator;
  // State field(s) for currentheight widget.
  FocusNode? currentheightFocusNode;
  TextEditingController? currentheightTextController;
  String? Function(BuildContext, String?)? currentheightTextControllerValidator;
  // State field(s) for nutrition widget.
  FocusNode? nutritionFocusNode;
  TextEditingController? nutritionTextController;
  String? Function(BuildContext, String?)? nutritionTextControllerValidator;
  // State field(s) for feeding widget.
  FocusNode? feedingFocusNode;
  TextEditingController? feedingTextController;
  String? Function(BuildContext, String?)? feedingTextControllerValidator;
  // State field(s) for pediatrician widget.
  FocusNode? pediatricianFocusNode;
  TextEditingController? pediatricianTextController;
  String? Function(BuildContext, String?)? pediatricianTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    firstnameFocusNode?.dispose();
    firstnameTextController?.dispose();

    lastnameFocusNode?.dispose();
    lastnameTextController?.dispose();

    firstnamemFocusNode?.dispose();
    firstnamemTextController?.dispose();

    lastnamemFocusNode?.dispose();
    lastnamemTextController?.dispose();

    dobFocusNode?.dispose();
    dobTextController?.dispose();

    genderFocusNode?.dispose();
    genderTextController?.dispose();

    birthweightFocusNode?.dispose();
    birthweightTextController?.dispose();

    currentweightFocusNode?.dispose();
    currentweightTextController?.dispose();

    currentheightFocusNode?.dispose();
    currentheightTextController?.dispose();

    nutritionFocusNode?.dispose();
    nutritionTextController?.dispose();

    feedingFocusNode?.dispose();
    feedingTextController?.dispose();

    pediatricianFocusNode?.dispose();
    pediatricianTextController?.dispose();
  }
}
