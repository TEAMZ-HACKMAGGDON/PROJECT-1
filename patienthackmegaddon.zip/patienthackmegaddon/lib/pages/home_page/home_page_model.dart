import '/flutter_flow/flutter_flow_autocomplete_options_list.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'home_page_widget.dart' show HomePageWidget;
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class HomePageModel extends FlutterFlowModel<HomePageWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for TabBar widget.
  TabController? tabBarController;
  int get tabBarCurrentIndex =>
      tabBarController != null ? tabBarController!.index : 0;

  // State field(s) for loginemail widget.
  final loginemailKey = GlobalKey();
  FocusNode? loginemailFocusNode;
  TextEditingController? loginemailTextController;
  String? loginemailSelectedOption;
  String? Function(BuildContext, String?)? loginemailTextControllerValidator;
  // State field(s) for loginpassword widget.
  final loginpasswordKey = GlobalKey();
  FocusNode? loginpasswordFocusNode;
  TextEditingController? loginpasswordTextController;
  String? loginpasswordSelectedOption;
  late bool loginpasswordVisibility;
  String? Function(BuildContext, String?)? loginpasswordTextControllerValidator;
  // State field(s) for signup_email widget.
  final signupEmailKey = GlobalKey();
  FocusNode? signupEmailFocusNode;
  TextEditingController? signupEmailTextController;
  String? signupEmailSelectedOption;
  String? Function(BuildContext, String?)? signupEmailTextControllerValidator;
  // State field(s) for signup_password widget.
  final signupPasswordKey = GlobalKey();
  FocusNode? signupPasswordFocusNode;
  TextEditingController? signupPasswordTextController;
  String? signupPasswordSelectedOption;
  late bool signupPasswordVisibility;
  String? Function(BuildContext, String?)?
      signupPasswordTextControllerValidator;
  // State field(s) for signup_confirm widget.
  final signupConfirmKey = GlobalKey();
  FocusNode? signupConfirmFocusNode;
  TextEditingController? signupConfirmTextController;
  String? signupConfirmSelectedOption;
  late bool signupConfirmVisibility;
  String? Function(BuildContext, String?)? signupConfirmTextControllerValidator;

  @override
  void initState(BuildContext context) {
    loginpasswordVisibility = false;
    signupPasswordVisibility = false;
    signupConfirmVisibility = false;
  }

  @override
  void dispose() {
    tabBarController?.dispose();
    loginemailFocusNode?.dispose();

    loginpasswordFocusNode?.dispose();

    signupEmailFocusNode?.dispose();

    signupPasswordFocusNode?.dispose();

    signupConfirmFocusNode?.dispose();
  }
}
