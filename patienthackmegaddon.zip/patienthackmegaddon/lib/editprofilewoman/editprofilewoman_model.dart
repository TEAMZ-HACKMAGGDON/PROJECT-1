import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'editprofilewoman_widget.dart' show EditprofilewomanWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class EditprofilewomanModel extends FlutterFlowModel<EditprofilewomanWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for firstnamem widget.
  FocusNode? firstnamemFocusNode;
  TextEditingController? firstnamemTextController;
  String? Function(BuildContext, String?)? firstnamemTextControllerValidator;
  // State field(s) for lastnamem widget.
  FocusNode? lastnamemFocusNode;
  TextEditingController? lastnamemTextController;
  String? Function(BuildContext, String?)? lastnamemTextControllerValidator;
  // State field(s) for age widget.
  FocusNode? ageFocusNode;
  TextEditingController? ageTextController;
  String? Function(BuildContext, String?)? ageTextControllerValidator;
  // State field(s) for address widget.
  FocusNode? addressFocusNode;
  TextEditingController? addressTextController;
  String? Function(BuildContext, String?)? addressTextControllerValidator;
  // State field(s) for phno widget.
  FocusNode? phnoFocusNode;
  TextEditingController? phnoTextController;
  String? Function(BuildContext, String?)? phnoTextControllerValidator;
  // State field(s) for email widget.
  FocusNode? emailFocusNode;
  TextEditingController? emailTextController;
  String? Function(BuildContext, String?)? emailTextControllerValidator;
  // State field(s) for maritalstatus widget.
  FocusNode? maritalstatusFocusNode;
  TextEditingController? maritalstatusTextController;
  String? Function(BuildContext, String?)? maritalstatusTextControllerValidator;
  // State field(s) for pregnancystatus widget.
  FocusNode? pregnancystatusFocusNode;
  TextEditingController? pregnancystatusTextController;
  String? Function(BuildContext, String?)?
      pregnancystatusTextControllerValidator;
  // State field(s) for gestationalage widget.
  FocusNode? gestationalageFocusNode;
  TextEditingController? gestationalageTextController;
  String? Function(BuildContext, String?)?
      gestationalageTextControllerValidator;
  // State field(s) for noofpregnacies widget.
  FocusNode? noofpregnaciesFocusNode;
  TextEditingController? noofpregnaciesTextController;
  String? Function(BuildContext, String?)?
      noofpregnaciesTextControllerValidator;
  // State field(s) for noofbirths widget.
  FocusNode? noofbirthsFocusNode;
  TextEditingController? noofbirthsTextController;
  String? Function(BuildContext, String?)? noofbirthsTextControllerValidator;
  // State field(s) for lastmenstrualcycle widget.
  FocusNode? lastmenstrualcycleFocusNode;
  TextEditingController? lastmenstrualcycleTextController;
  String? Function(BuildContext, String?)?
      lastmenstrualcycleTextControllerValidator;
  // State field(s) for expecteddeliverydate widget.
  FocusNode? expecteddeliverydateFocusNode;
  TextEditingController? expecteddeliverydateTextController;
  String? Function(BuildContext, String?)?
      expecteddeliverydateTextControllerValidator;
  // State field(s) for deliverytype widget.
  FocusNode? deliverytypeFocusNode;
  TextEditingController? deliverytypeTextController;
  String? Function(BuildContext, String?)? deliverytypeTextControllerValidator;
  // State field(s) for doctor widget.
  FocusNode? doctorFocusNode;
  TextEditingController? doctorTextController;
  String? Function(BuildContext, String?)? doctorTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    firstnamemFocusNode?.dispose();
    firstnamemTextController?.dispose();

    lastnamemFocusNode?.dispose();
    lastnamemTextController?.dispose();

    ageFocusNode?.dispose();
    ageTextController?.dispose();

    addressFocusNode?.dispose();
    addressTextController?.dispose();

    phnoFocusNode?.dispose();
    phnoTextController?.dispose();

    emailFocusNode?.dispose();
    emailTextController?.dispose();

    maritalstatusFocusNode?.dispose();
    maritalstatusTextController?.dispose();

    pregnancystatusFocusNode?.dispose();
    pregnancystatusTextController?.dispose();

    gestationalageFocusNode?.dispose();
    gestationalageTextController?.dispose();

    noofpregnaciesFocusNode?.dispose();
    noofpregnaciesTextController?.dispose();

    noofbirthsFocusNode?.dispose();
    noofbirthsTextController?.dispose();

    lastmenstrualcycleFocusNode?.dispose();
    lastmenstrualcycleTextController?.dispose();

    expecteddeliverydateFocusNode?.dispose();
    expecteddeliverydateTextController?.dispose();

    deliverytypeFocusNode?.dispose();
    deliverytypeTextController?.dispose();

    doctorFocusNode?.dispose();
    doctorTextController?.dispose();
  }
}
