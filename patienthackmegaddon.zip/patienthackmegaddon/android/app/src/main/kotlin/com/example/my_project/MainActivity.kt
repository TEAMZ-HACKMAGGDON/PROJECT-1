package com.mycompany.patienthackmegaddon

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
